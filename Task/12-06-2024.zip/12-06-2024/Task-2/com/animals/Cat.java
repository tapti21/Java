// File: com/animals/Cat.java
package com.animals;

public class Cat extends Animal {
    @Override
    public void sound() {
        System.out.println("Meow");
    }
}

