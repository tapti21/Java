// File: com/animals/Dog.java
package com.animals;

public class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Bark");
    }
}
