// File: com/media/DVD.java
package com.media;

public class DVD extends Media {
    @Override
    public void displayInfo() {
        System.out.println("DVD information");
    }
}

