// File: com/media/CD.java
package com.media;

public class CD extends Media {
    @Override
    public void displayInfo() {
        System.out.println("CD information");
    }
}

