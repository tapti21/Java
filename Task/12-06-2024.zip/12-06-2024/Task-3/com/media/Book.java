// File: com/media/Book.java
package com.media;

public class Book extends Media {
    @Override
    public void displayInfo() {
        System.out.println("Book information");
    }
}

