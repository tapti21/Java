// File: com/media/Media.java
package com.media;

public class Media {
    public void displayInfo() {
        System.out.println("Generic media info");
    }
}

