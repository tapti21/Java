package In.Allahabad.Springcrud;


public class App 
{
    public static void main( String[] args )
    {
    	try {ApplicationContext cxt = new
    			AnnotationConfigApplicationContext(ConfigFile.clsaa);
    	
    	}
        
    }
}
