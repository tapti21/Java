package in.sp.beans;

public class Student {
	private name;
	private mail;
	private location;

}
