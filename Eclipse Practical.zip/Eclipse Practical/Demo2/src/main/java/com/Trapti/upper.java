package com.Trapti;

public class upper {

//	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	public static String makeupper(String data) {
		return data
	}

	}


