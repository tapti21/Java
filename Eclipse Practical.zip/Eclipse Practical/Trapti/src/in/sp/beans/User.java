package in.sp.beans;

public class User {

}
