// class A{
//     Variable
//     String name = "trapti";
//     String location = "Etawah";
// }

        //  Abstract Class  //
// abstract class A{
//     abstract void display();
// }

// class B extends A{
//     public void display(){
//         System.out.println("Hello");
//     }
// }



public class pat {
    public static void main(String[] args) {
        // B obj = new B();
        // obj.display();

        
        
    }
    
}
