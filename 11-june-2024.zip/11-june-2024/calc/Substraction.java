package calc;

public class Substraction extends Division{
    public int sub(int a, int b){
        return a-b;
    }

}
