package calc;


public class Division extends Multiplication{
    public int div(int a, int b) {
        return a/b;
    }
}
