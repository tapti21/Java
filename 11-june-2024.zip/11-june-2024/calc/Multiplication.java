package calc;

public class Multiplication{
    public int multi(int a, int b){
        return a*b;
    }
}
